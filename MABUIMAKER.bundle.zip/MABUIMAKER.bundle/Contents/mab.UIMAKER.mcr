macroScript UIMAKER category:"MYARTSBOX" tooltip:"UI Maker"
(
    filein "mab.UIMAKER.ms" 
)